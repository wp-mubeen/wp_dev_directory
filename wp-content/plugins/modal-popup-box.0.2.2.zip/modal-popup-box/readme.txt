﻿=== Modal Popup Box - Shortcode Popup, Coupon Popup, Offer Popup ===
Contributors: awordpresslife
Tags: advertising, modal popup, responsive popups, popup box, shortcode Popup
Donate link: http://awplife.com/
Requires at least: 4.0
Tested up to: 4.9.4
Stable tag: 0.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shortcode Popup, Coupon Popup, Offer Popup. popup box a set of experimental modal window appearance effects with CSS transitions and animations.

== Description ==

= Popup Maker, Popup builder, Shortcode Popup, Coupon Popup, Offer Popup =

This is the new “Modal Popup Box WordPress Plugin”.

Modal Popup Box is based on Irresistible CSS & JS, So it is very amazing and easy to use.

Popup  is a modal popup plugin for WordPress website that allows you to add highly customizable pop up windows. This plugin will enable awesome popup in your WordPress website using short codes. You can add unlimited popups with their own configurations. We added effective settings’-panel for each popup. So, you can fully customize the popup themes, colors, sizes and many other options.

With Modal Popup Box WordPress Plugin, it is dynamic you can show anything in this popup box like posts, discount offers, other plugins just paste the shortcode in the editor field.

This is the best popup box plugin for any site Because this modal popup box has many configurations to show your content with details on the site.

You can use it also in the sidebar like a widget, Just paste the shortcode in the text widget and also you can use it with any post, this plugin easier to customize.

It will be very helpful for new users, this plug in very easy in use for new and old users of WordPress.

An Easy And Powerful modal popup box plugin for wordpress.

https://www.youtube.com/watch?v=t9lVWwCio-s&index=1&list=PLXR1UeeO9dcfQlISdBbSmogLOwJt4TPra

**Video Popup**

Every single day lots of information and news is shared by a number of people online. And it is widespread knowledge that any information transmitted visually is more comprehensible and competitive, as motion pictures, video clips, etc. give any material somehow a unique flavour.
Surely, many of you would like to take advantage of the opportunity that this video popup offers. It can help to emphasize or season your ideas. You will be able to add video content (YouTube, Vimeo, etc.) by putting its video URL in the popup options.

**Upgrade To Premium Plugin - <a href="http://awplife.com/product/model-popup-box-premium/">Click Here</a>**

**Check Premium Plugin Demo - <a href="http://demo.awplife.com/model-popup-box-pemium/">Click Here</a>**

**Get Premium Version With More Features**

* Animation Effects
* Responsive Design
* Onload or Onclick Function
* Height & Width Settings
* Heading Text Alignment
* Button Text Alignment
* 20+ Effects
* Paste Your gallery shortcode into pop up box
* insert portfolio into modal popup box
* create iFrame into popup box
* insert video into popup box
* insert GoogleMap into modal pop up box 
* Button Link Settings
* On Page LOad Popup
* Shortcode
* Color Picker
* Font Color
* Button Settings
* Button Loading Effects
* Overlay settings
* Custom CSS
* Loading Effects
* Paste Your gallery shortcode into pop up box


== Installation ==

Install Modal Pop Box either via the WordPress.org plugin directory or by uploading the files to your server.

After activating Modal Pop Box, go to plugin menu.

Click Add Modal Pop Box and write the content in the text box.

Publish the modal pop box and copy modal pop box shortcode from the bottom of the add images box and embed shortcode on any Page/Post/Text Widget.

That's it. You're ready to go!

== Frequently Asked Questions ==

Have any queries?

Please post your question on plugin support forum

https://wordpress.org/plugins/modal-popup-box/

== Screenshots ==

1. Show Gallery into Modal Pop Box
2. Youtube Video into Modal Pop Box
3. Soundclude Audio into Modal Pop Box
4. Contact Form into Modal Pop Box
5. Insta Type Gallery into Modal Pop Box
6. Portfolio Filter Gallery in Modal Pop Box

== Changelog ==

= 0.2.2 =
* Enhancements: Yes, Tested for wordpress 4.9
* Bug Fix: None
* Additional changes: Yes, Added Featured Page.

= 0.2.1 =
* Enhancements: Yes, Tested for wordpress 4.9
* Bug Fix: None
* Additional changes: Yes, Added theme page

Feature Enhancements: Version 0.2.0
* Enhancements: None
* Bug Fix: Yes
* Additional changes: None

Feature Enhancements: Version 0.1.9
* Enhancements: None
* Bug Fix: Yes
* Additional changes: None

Feature Enhancements: Version 0.1.8
* Enhancements: None
* Bug Fix: Yes, a bug fixed and add a link
* Additional changes: None

Feature Enhancements: Version 0.1.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.6
* Enhancements: Tested Upto New version 4.8.1
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.5
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.4
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.3
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.2
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.1
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.0
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.9
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.8
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.6
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.5
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.4
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.3
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.2
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.1
* Enhancements: None
* Bug Fix: None
* Additional changes: None

== Upgrade Notice ==
This is an initial release. Start with version 0.0.1 and share your feedback <a href="https://wordpress.org/support/view/plugin-reviews/new-album-gallery//">here</a>.